//
//  ChatListTableViewCell.swift
//  chatwoot
//
//  Created by shamzz on 01/11/21.
//

import UIKit

class ChatListTableViewCell: UITableViewCell {
    static let id = String(describing: ChatListTableViewCell.self)

    @IBOutlet weak var lblAuthor      : UILabel!
    @IBOutlet weak var lblMessage     : UILabel!
    @IBOutlet weak var lblDate        : UILabel!
    @IBOutlet weak var lblCount       : UILabel!
    @IBOutlet weak var lblCountHolder : UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        

    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}

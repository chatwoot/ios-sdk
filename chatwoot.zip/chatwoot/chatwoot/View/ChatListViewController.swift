//
//  ChatListViewController.swift
//  chatwoot
//
//  Created by shamzz on 21/09/21.
//

import UIKit

class ChatListViewController: UIViewController {
    
    @IBOutlet weak var chatListTableView  : UITableView!

    private var switchAccountViewModel = SwitchAccountViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        chatListTableView.tableFooterView = UIView.init(frame: CGRect.zero)
    }
    
    @IBAction func switchAccountAction(_ sender: Any) {
        switchAccountViewModel.delegate = self
        switchAccountViewModel.callSwitchAccountApi()
    }
}

extension ChatListViewController: SwitchAccountDelegate {
    func getAccessToken(data: SwitchAccountModel) {
        print(data,getAccessToken)
    }
}

extension ChatListViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ChatListTableViewCell.id, for: indexPath) as! ChatListTableViewCell
        cell.lblCount.text = "10"
        return cell
    }
}

extension ChatListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}



